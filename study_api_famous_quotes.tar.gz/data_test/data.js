[
    {
    "_id": "h12ulAfEEIi1",
    "content": "Focusing your life solely on making a buck shows a poverty of ambition. It asks too little of yourself. And it will leave you unfulfilled.",
    "author": "Barack Obama",
    "tags": ["Success", "Famous Quotes"]
  }
]